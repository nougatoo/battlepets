<?php


require_once('util.php');

set_time_limit(0);
ini_set('memory_limit', '1024M');

$conn = dbConnect();
$distinctPets = [];

$result = $conn->prepare("SELECT distinct species_id FROM market_value_pets");
$result->execute();	

if($result) {	
	while($row = $result->fetch()) {
		$distinctPets.push($row['species_id'])
	}
}


// Go through each pet 
foreach ($distinctPets as $key => $aSpecies) {

	$marketValues = [];
	
	$result = $conn->prepare("SELECT market_value_pets.species_id, market_value_pets.market_value, pets.name FROM market_value_pets INNER JOIN pets ON pets.species_id = market_value_pets.species_id WHERE market_value_pets.species_id = '".$aSpecies['species_id']."'");
	$result->execute();
	
	if($result) {	
	while($row = $result->fetch()) {
		$marketValues.push($row['market_value_pets.market_value']);
	}
	
	// Now we have all buyout for a species
	
	// Sort least to greatest
	sort($petBuyouts);
	$medianIndex = floor(sizeof($petBuyouts));
	$medianValue = $petBuyouts[$medianIndex];
	
	echo "Species ID: ".$aSpecies['market_value_pets.species_id']." Name: ".$aSpecies['pets.name']." Market Value: ".$medianValue."<br/>";
}

?>
