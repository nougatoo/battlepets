<?php

return array(
    'threshLeggo' => 500000000,
    'threshEpic' => 200000000,
    'threshBlue' => 100000000,
    'threshGreen' => 30000000,
	'maxGblBuyPercent' => 0.55, // No longer in use - changed to a front-end user option
	'maxGblSnipePercent' => 0.15,
	'minGblBuyAmount' => 10000000,
	'minGblSellPercent' => 0.75 // The minimum i would sell a pet for
);